// Explicit Vercel serverless entrypoint.
// Keeping the Express app in server.js lets it run locally with `npm start` too.
const app = require('../server');
module.exports = app;
