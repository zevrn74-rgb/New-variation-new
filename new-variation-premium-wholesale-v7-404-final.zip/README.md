# NEW VARIATION — Vercel Managed Wholesale Catalogue v4

Vercel-ready Express catalogue with a stateless admin cookie and Vercel Blob storage.

## Fixed
- Removed SQLite/local filesystem persistence.
- Removed Docker-only deployment files from the Vercel package.
- Uses Vercel Blob for catalogue state and product images.
- Node.js 24.x.
- Product uploads limited to 4 MB to stay below Vercel function request limits.
- No default admin credentials or fake contact numbers.
- Clear configuration errors instead of crashing when Blob is missing.
- Admin supports products, images, stock, pricing, offers and business settings.

## Deploy
1. Import the project into Vercel.
2. Create/connect a **Public Vercel Blob** store to the project.
3. Add `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `SESSION_SECRET`, `WHATSAPP_NUMBER`, and `BUSINESS_EMAIL`.
4. Ensure `BLOB_READ_WRITE_TOKEN` is present for the connected Blob store.
5. Deploy.
6. Visit `/` and `/admin`.

Never commit real credentials to GitHub.
