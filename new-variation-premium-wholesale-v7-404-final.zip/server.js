const express = require('express');
const path = require('path');
const crypto = require('crypto');
const { put, list, del } = require('@vercel/blob');
const multer = require('multer');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const STATE_PREFIX = 'new-variation/state-';
const COOKIE_NAME = 'nv_admin';

const seedProducts = [
  {id:1,name:'Performance Track Pant',sku:'NV-TRK-01',category:'Trackwear',description:'Lightweight fabric · Zip pockets · Adjustable waist',price:249,stock:50,image:'/assets/product-01.jpg',badge:'FEATURED',featured:true,active:true,sizes:['M','L','XL','XXL'],colors:['Black','Grey','Navy'],fabric:'Performance polyester',fit:'Regular fit',moq:20},
  {id:2,name:'Camouflage Stripe Pant',sku:'NV-TRK-02',category:'Trackwear',description:'Statement camo · Contrast side stripes · Relaxed fit',price:279,stock:40,image:'/assets/product-02.jpg',badge:'NEW',featured:false,active:true,sizes:['M','L','XL','XXL'],colors:['Olive','Brown','Black','Grey'],fabric:'Cotton blend',fit:'Relaxed fit',moq:20},
  {id:3,name:'Urban Camo Track Pant',sku:'NV-TRK-03',category:'Activewear',description:'Multiple colourways · Elastic waist · Daily comfort',price:269,stock:35,image:'/assets/product-03.jpg',badge:'4 COLORS',featured:false,active:true,sizes:['M','L','XL','XXL'],colors:['Grey','Brown','Olive','Black'],fabric:'Breathable poly blend',fit:'Tapered fit',moq:20},
  {id:4,name:'Camouflage Daily Jogger',sku:'NV-TRK-04',category:'Trackwear',description:'Soft hand feel · Tapered profile · Retail-ready styles',price:289,stock:60,image:'/assets/product-04.jpg',badge:'POPULAR',featured:false,active:true,sizes:['M','L','XL','XXL'],colors:['Grey','Olive','Black'],fabric:'Soft cotton blend',fit:'Tapered fit',moq:20}
];

const defaults = {
  business_name: 'NEW VARIATION',
  tagline: 'Premium wholesale apparel for retailers, resellers and growing fashion businesses.',
  whatsapp: process.env.WHATSAPP_NUMBER || '918384059345',
  email: process.env.BUSINESS_EMAIL || ''
};

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 4 * 1024 * 1024 },
  fileFilter: (req, file, cb) => cb(null, /^image\/(jpeg|png|webp)$/.test(file.mimetype))
});

app.use(express.json({limit:'2mb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(ROOT,'public')));

app.get('/api/health',(req,res)=>res.json({ok:true,service:'new-variation',storageConfigured:storageConfigured()}));

function secret(){ return process.env.SESSION_SECRET || 'change-this-session-secret'; }
function sign(value){ return crypto.createHmac('sha256', secret()).update(value).digest('base64url'); }
function makeToken(username){
  const payload = Buffer.from(JSON.stringify({u:username,exp:Date.now()+8*60*60*1000})).toString('base64url');
  return `${payload}.${sign(payload)}`;
}
function readCookie(req,name){
  const raw=req.headers.cookie||'';
  for(const part of raw.split(';')){const i=part.indexOf('=');if(i<0)continue;if(part.slice(0,i).trim()===name)return decodeURIComponent(part.slice(i+1));}
  return null;
}
function currentAdmin(req){
  try{
    const token=readCookie(req,COOKIE_NAME); if(!token)return null;
    const [payload,sig]=token.split('.'); if(!payload||!sig||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(sign(payload))))return null;
    const data=JSON.parse(Buffer.from(payload,'base64url').toString());
    if(!data.u||!data.exp||data.exp<Date.now())return null;
    return data.u;
  }catch{return null;}
}
function setCookie(res,value){
  const secure=true;
  res.setHeader('Set-Cookie',`${COOKIE_NAME}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${8*60*60}${secure?'; Secure':''}`);
}
function clearCookie(res){res.setHeader('Set-Cookie',`${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0; Secure`);}
function requireAdmin(req,res,next){const u=currentAdmin(req);if(u){req.admin=u;return next();}return res.status(401).json({error:'Unauthorized'});}
function adminCredentials(){
  const username=String(process.env.ADMIN_USERNAME||'').trim();
  const password=String(process.env.ADMIN_PASSWORD||'');
  if(!username||!password) throw new Error('Admin credentials are not configured.');
  return {username,password};
}

function freshState(){return {products:structuredClone(seedProducts),offers:[],settings:{...defaults},updatedAt:new Date().toISOString()};}
function storageConfigured(){return !!process.env.BLOB_READ_WRITE_TOKEN;}
function requireStorage(){if(!storageConfigured()) throw new Error('Vercel Blob is not connected. Create/connect a Blob store and add BLOB_READ_WRITE_TOKEN.');}

async function findStateBlob(){requireStorage();
  const result=await list({prefix:STATE_PREFIX,limit:100});
  const items=(result.blobs||[]).filter(x=>x.pathname.startsWith(STATE_PREFIX));
  if(!items.length)return null;
  items.sort((a,b)=>String(b.uploadedAt||b.pathname).localeCompare(String(a.uploadedAt||a.pathname)));
  return items[0];
}
async function readState(){
  const blob=await findStateBlob();
  if(!blob){const state=freshState();await writeState(state);return state;}
  const response=await fetch(`${blob.url}${blob.url.includes('?')?'&':'?'}cacheBust=${Date.now()}`);
  if(!response.ok)throw new Error(`Storage read failed (${response.status})`);
  return await response.json();
}
async function writeState(state){requireStorage();
  state.updatedAt=new Date().toISOString();
  const previous=await findStateBlob();
  const pathname=`${STATE_PREFIX}${Date.now()}-${crypto.randomBytes(3).toString('hex')}.json`;
  const blob=await put(pathname,JSON.stringify(state),{access:'public',contentType:'application/json',addRandomSuffix:false});
  if(previous && previous.url!==blob.url){try{await del(previous.url)}catch{}}
  return state;
}
async function mutateState(fn){const state=await readState();const result=await fn(state);await writeState(state);return result===undefined?state:result;}
function normalizeProduct(p){return {...p,sizes:Array.isArray(p.sizes)?p.sizes:[],colors:Array.isArray(p.colors)?p.colors:[],fabric:String(p.fabric||''),fit:String(p.fit||''),moq:Number(p.moq||0),featured:!!p.featured,active:!!p.active};}
function nextId(items){return items.reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1;}

app.get('/api/products',async(req,res)=>{try{const s=await readState();res.json(s.products.filter(p=>p.active).sort((a,b)=>Number(b.featured)-Number(a.featured)||b.id-a.id).map(normalizeProduct));}catch(e){console.error(e);res.status(503).json({error:e.message});}});
app.get('/api/offers',async(req,res)=>{try{const s=await readState();res.json(s.offers.filter(o=>o.active).sort((a,b)=>b.id-a.id));}catch(e){console.error(e);res.status(500).json({error:e.message});}});
app.get('/api/settings',async(req,res)=>{try{const s=await readState();res.json(s.settings);}catch(e){console.error(e);res.status(500).json({error:e.message});}});

app.post('/api/login',(req,res)=>{
  try{
    const {username,password}=req.body||{};
    const c=adminCredentials();
    if(username===c.username && password===c.password){setCookie(res,makeToken(username));return res.json({ok:true,username});}
    res.status(401).json({error:'Invalid username or password'});
  }catch(e){res.status(503).json({error:e.message});}
});
app.post('/api/logout',(req,res)=>{clearCookie(res);res.json({ok:true});});
app.get('/api/me',(req,res)=>{const username=currentAdmin(req);res.json({authenticated:!!username,username:username||null});});

app.get('/api/admin/products',requireAdmin,async(req,res)=>{try{const s=await readState();res.json(s.products.map(normalizeProduct).sort((a,b)=>b.id-a.id));}catch(e){res.status(500).json({error:e.message});}});

app.post('/api/admin/products',requireAdmin,upload.single('image'),async(req,res)=>{
  try{
    const b=req.body||{}; const product={id:0,name:String(b.name||'').trim(),sku:String(b.sku||'').trim(),category:String(b.category||'Trackwear').trim(),description:String(b.description||''),price:Number(b.price||0),stock:Number(b.stock||0),image:String(b.image||''),badge:String(b.badge||''),featured:b.featured==='1',active:b.active!=='0',sizes:String(b.sizes||'').split(',').map(x=>x.trim()).filter(Boolean),colors:String(b.colors||'').split(',').map(x=>x.trim()).filter(Boolean),fabric:String(b.fabric||'').trim(),fit:String(b.fit||'').trim(),moq:Number(b.moq||0)};
    if(!product.name||!product.sku)return res.status(400).json({error:'Name and SKU are required'});
    if(req.file){const ext=req.file.mimetype.split('/')[1].replace('jpeg','jpg');const blob=await put(`new-variation/products/${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`,req.file.buffer,{access:'public',contentType:req.file.mimetype});product.image=blob.url;}
    const out=await mutateState(s=>{if(s.products.some(p=>p.sku.toLowerCase()===product.sku.toLowerCase()))throw new Error('SKU already exists');product.id=nextId(s.products);s.products.push(product);return normalizeProduct(product);});
    res.json(out);
  }catch(e){console.error(e);res.status(400).json({error:e.message});}
});

app.put('/api/admin/products/:id',requireAdmin,upload.single('image'),async(req,res)=>{
  try{
    const id=Number(req.params.id); const b=req.body||{}; let oldImage='';
    const out=await mutateState(async s=>{
      const p=s.products.find(x=>x.id===id);if(!p)throw new Error('Product not found');oldImage=p.image||'';
      const sku=String(b.sku||'').trim();if(s.products.some(x=>x.id!==id&&x.sku.toLowerCase()===sku.toLowerCase()))throw new Error('SKU already exists');
      Object.assign(p,{name:String(b.name||'').trim(),sku,category:String(b.category||'Trackwear').trim(),description:String(b.description||''),price:Number(b.price||0),stock:Number(b.stock||0),badge:String(b.badge||''),featured:b.featured==='1',active:b.active!=='0',sizes:String(b.sizes||'').split(',').map(x=>x.trim()).filter(Boolean),colors:String(b.colors||'').split(',').map(x=>x.trim()).filter(Boolean),fabric:String(b.fabric||'').trim(),fit:String(b.fit||'').trim(),moq:Number(b.moq||0)});
      if(req.file){const ext=req.file.mimetype.split('/')[1].replace('jpeg','jpg');const blob=await put(`new-variation/products/${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`,req.file.buffer,{access:'public',contentType:req.file.mimetype});p.image=blob.url;}
      return normalizeProduct(p);
    });
    if(req.file && oldImage && oldImage.includes('.blob.vercel-storage.com')){try{await del(oldImage)}catch{}}
    res.json(out);
  }catch(e){console.error(e);res.status(400).json({error:e.message});}
});
app.delete('/api/admin/products/:id',requireAdmin,async(req,res)=>{try{const id=Number(req.params.id);const out=await mutateState(async s=>{const i=s.products.findIndex(p=>p.id===id);if(i<0)throw new Error('Not found');const [p]=s.products.splice(i,1);if(p.image&&p.image.includes('.blob.vercel-storage.com')){try{await del(p.image)}catch{}}return {ok:true};});res.json(out);}catch(e){res.status(400).json({error:e.message});}});

app.get('/api/admin/offers',requireAdmin,async(req,res)=>{try{const s=await readState();res.json(s.offers.sort((a,b)=>b.id-a.id));}catch(e){res.status(500).json({error:e.message});}});
app.post('/api/admin/offers',requireAdmin,async(req,res)=>{try{const b=req.body||{};const out=await mutateState(s=>{const o={id:nextId(s.offers),title:String(b.title||'').trim(),description:String(b.description||''),discount:String(b.discount||''),active:b.active!=='0'};if(!o.title)throw new Error('Title is required');s.offers.push(o);return o;});res.json(out);}catch(e){res.status(400).json({error:e.message});}});
app.put('/api/admin/offers/:id',requireAdmin,async(req,res)=>{try{const id=Number(req.params.id);const out=await mutateState(s=>{const o=s.offers.find(x=>x.id===id);if(!o)throw new Error('Offer not found');Object.assign(o,{title:String(req.body.title||'').trim(),description:String(req.body.description||''),discount:String(req.body.discount||''),active:req.body.active!=='0'});return o;});res.json(out);}catch(e){res.status(400).json({error:e.message});}});
app.delete('/api/admin/offers/:id',requireAdmin,async(req,res)=>{try{const id=Number(req.params.id);await mutateState(s=>{const i=s.offers.findIndex(x=>x.id===id);if(i<0)throw new Error('Offer not found');s.offers.splice(i,1);});res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});

app.put('/api/admin/settings',requireAdmin,async(req,res)=>{try{const settings=await mutateState(s=>{for(const [key,value] of Object.entries(req.body||{}))if(['business_name','tagline','whatsapp','email'].includes(key))s.settings[key]=String(value);return s.settings;});res.json(settings);}catch(e){res.status(400).json({error:e.message});}});

app.get('/admin',(req,res)=>res.sendFile(path.join(ROOT,'public','admin.html')));
app.use((req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));

if(require.main===module){app.listen(PORT,'0.0.0.0',()=>console.log(`New Variation catalogue running on http://localhost:${PORT}`));}
module.exports=app;
